#pragma once

namespace assignment1 {
	class Input
	{
	public:
		static void KbEventHandler(unsigned char key, int x, int y);
	};
}
